package br.com.dio.collection.streamAPI;

public class ExemploStream {
}
